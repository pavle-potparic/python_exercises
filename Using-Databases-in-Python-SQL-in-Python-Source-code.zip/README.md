"# python_exercises" 
